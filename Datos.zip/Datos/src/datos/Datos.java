
import java.io.File;
import java.io.IOException;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Datos extends JFrame {
    public Datos() {
        super("Datos");

        JTextArea textArea = new JTextArea(20, 40);
        add(textArea);

        String archivo = "Empresas_Registradas_C_mara_Comercio.csv";

        try {
            try (BufferedReader lector = new BufferedReader(new FileReader(archivo))) {
                String linea;
                // Leer línea por línea del archivo de texto
                int n = 100;
                while ((linea = lector.readLine()) != null && --n>0) {
                    textArea.append(linea + "\n");
                }
                // Cerrar el lector
            }
        } catch (IOException e) {
            textArea.setText("Error al leer el archivo: " + e.getMessage());
        }

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        Datos datos = new Datos();
    }
} 
class XYChartExample {

    public static void main(String[] args) {

    // Crear un gráfico xy simple
    XYSeries series = new XYSeries("XYGraph");
    series.add(1, 1);
    series.add(1, 2);
    series.add(2, 1);
    series.add(3, 9);
    series.add(4, 10);

// Agregar las series de datos
    XYSeriesCollection dataset = new XYSeriesCollection();
    dataset.addSeries(series);

// Generar el gráfico
    JFreeChart chart = ChartFactory.createXYLineChart(
    "XY Chart", // Título
    "Eje x", // etiqueta para el eje x
    "Eje y", // etiqueta para el eje y
    dataset, // Dataset
    PlotOrientation.VERTICAL, // Orientación
    true, // Mostrar leyenda
    true, // Usar tooltips
    false // Configurar para generar URLs
);

// Generar un archivo con el gráfico
    try {
        ChartUtilities.saveChartAsJPEG(new File("chart.jpg"), chart, 500, 300);
        } catch (IOException e) {
            System.err.println("Error al crear el archivo.");
        }
    }
} 